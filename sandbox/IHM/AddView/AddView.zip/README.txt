A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/rxoadE.

 Démo formulaires HTML 5

Forked from [3W Academy](http://codepen.io/sheoak/)'s Pen [Vive les formulaires](http://codepen.io/sheoak/pen/cnHCh/).