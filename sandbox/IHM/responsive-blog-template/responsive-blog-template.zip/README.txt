A Pen created at CodePen.io. You can find this one at http://codepen.io/DaBhai13/pen/pvKZjZ.

 A Fully Responsive Blog Template