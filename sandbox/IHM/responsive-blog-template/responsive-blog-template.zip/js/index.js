$('.menu-bar').on('click', function(){
	$('nav ul').toggleClass('reveal');
});