package com.example.jetty_jersey.ws;

import java.util.ArrayList;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("/ws")
public class ExampleResource {
	
	public static class Flight {
		public String field;
	}
	
	ArrayList<ExampleResource.Flight> myFlightList;
	
	public ExampleResource(){
		myFlightList = new ArrayList<ExampleResource.Flight>();
		for (int i = 0; i < 10; i++){
			Flight instance = new Flight();
			instance.field = "Item " + i;	
			myFlightList.add(instance);
		}
	}
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes("application/json")
	@Path("/flight/{num}")
	public Flight getFlightById(@PathParam("num") int n){
		return myFlightList.get(n);
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/flight")
	public ArrayList<Flight> getFlightList() {
		return myFlightList;
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/flight/{num}")
	public ArrayList<Flight> retrieveExample(@PathParam("num") int num, Flight instance) {
		myFlightList.set(num, instance);
		return myFlightList;
	}

	@PUT
	@Consumes("application/json")
	@Produces("application/json")
	@Path("/flight")
	public ArrayList<Flight> addFlight(ArrayList<Flight> flights) {
		for (Flight f : flights){
			myFlightList.add(f);
		}
		return myFlightList;
	}
	
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/flight/{num}")
	public ArrayList<Flight> removeFlightById(@PathParam("num") String num){
		int id = Integer.parseInt(num);
		myFlightList.remove(id);
		return myFlightList;
	}
}
